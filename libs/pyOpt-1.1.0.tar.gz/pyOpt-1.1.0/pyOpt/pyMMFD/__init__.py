#!/usr/bin/env python

try:
    from pyMMFD import MMFD
    __all__ = ['MMFD']
except:
    __all__ = []
#end
