#!/usr/bin/env python

try:
    from pyALHSO import ALHSO
    __all__ = ['ALHSO']
except:
    __all__ = []
#end
