#!/usr/bin/env python

try:
    from pySNOPT import SNOPT
    __all__ = ['SNOPT']
except:
    __all__ = []
#end
