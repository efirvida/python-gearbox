#!/usr/bin/env python

try:
    from pySLSQP import SLSQP
    __all__ = ['SLSQP']
except:
    __all__ = []
#end
