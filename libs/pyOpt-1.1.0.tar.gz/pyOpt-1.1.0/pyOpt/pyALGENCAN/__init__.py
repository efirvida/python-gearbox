#!/usr/bin/env python

try:
    from pyALGENCAN import ALGENCAN
    __all__ = ['ALGENCAN']
except:
    __all__ = []
#end
