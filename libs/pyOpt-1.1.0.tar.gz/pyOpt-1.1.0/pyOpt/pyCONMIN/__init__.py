#!/usr/bin/env python

try:
    from pyCONMIN import CONMIN
    __all__ = ['CONMIN']
except:
    __all__ = []
#end
