#!/usr/bin/env python

try:
    from pyFSQP import FSQP
    __all__ = ['FSQP']
except:
    __all__ = []
#end
